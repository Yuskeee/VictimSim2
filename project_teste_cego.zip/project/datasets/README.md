This folder contains the configuration files and vital signal datasets for different scenarios and purposes.

The name of the folder represents:  
- the number of victims
- the size of the grid: columns x rows 

For instance, a folder named
* `data_400v_20x32` would contain a enviroment of 20 cols x 32 rows with 400 victims.
* `data_800v` would_ contain only the vital signals of the victims for regression/classification tasks. In this case, we omit the width x height information.
